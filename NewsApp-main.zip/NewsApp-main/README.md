This Application Uses React.Js along with React-Router to manage the frontend of the application.
We have used a external API to fetch news data and display it on the page using Node.Js
For styling and others features we have used BootStrap library in this application.
